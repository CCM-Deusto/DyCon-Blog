close all

%% 
% Read the data from the external file data.txt

fid= fopen('data_Nx20Nt100_mintime_UP.txt','r');
C = fscanf(fid,'%f',Inf);
T = C(1);                                        
Nx = C(2);
Nt = C(3);
y = C(4:(Nt+1)*Nx+3); 
u = C((Nt+1)*Nx+4:end);
fclose(fid);                          

%% 
% Reshape the state y and the control u into two Nx times Nt+1 matrices
y = reshape(y,Nx,Nt+1);
u = reshape(u,Nx,Nt+1);

%%
% Recover the control for controllability to trajectories

xline = linspace(-1,1,Nx);
dt = T/Nt;
tline = 0:dt:T;

a = -0.3; b = 0.8;
control = (xline>=a).*(xline<=b);
B = diag(control);

utarget = y*0+0.2;
v = u+B*utarget;

%% 
% For visibility reasons in the plots, set to zero the values of the
% control below the tolerance 10^(-5)
w = v;
w(w<=1e-5) = 0;

%% 
% Again for visibility reasons, generate from w a new control on a refined
% mesh, bot in space an time. 

k = 5;
xlineREF = linspace(-1,1,k*Nx);
p = 2;
tlineREF = linspace(0,T,p*Nt);

W1 = zeros(k*Nx,Nt+1);
for i = 1:Nx
    if mod(k*i,k) == 0
        W1(k*i,:) = k*w(i,1:end);
    end
end

W2 = zeros(k*Nx,p*Nt);
for j = 1:Nt
    if mod(p*j,p) == 0
       W2(:,p*j) = p*W1(:,j);
    end
end

%%
% Plot of the refined control W2. For attenuating the difference between
% the high and low picks and improving the visibility, the plot is done in 
% logaritmic scale.

figure1 = figure;
axes1 = axes('Parent',figure1);
surf(xlineREF,tlineREF,log10(1+W2)')
caxis([0,3])
shading interp
colormap jet
colorbar
box off
view(axes1,[114.4 51.2]);
xlim([xlineREF(1) xlineREF(end)])
ylim([tlineREF(1) tlineREF(end)])
set(gca,'visible','off')
cbh = colorbar('peer',axes1);
zticks([])
cbh.Ticks = linspace(0,3,5) ; 
cbh.TickLabels = ({'0','8.3\cdot 10^3','1.7\cdot 10^4','2.5\cdot 10^4','3.3\cdot 10^4'});
cbh.FontSize = 24;
cbh.Location = 'southoutside';
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0, 0.04, 1, 0.96])
a = get(gca,'XTickLabel');
set(gca,'XTickLabel',a,'fontsize',24)


%% Calculate Target
a = -0.3; b = 0.8;
B = BInterior(xline,a,b);
A = -FEFractionalLaplacian(0.8,1,length(xline));

dyn = pde('A',A,'B',B);
dyn.FinalTime = T;
dyn.Nt = length(tline);
dyn.mesh = xline;

dyn.InitialCondition = 6*cos(0.5*pi*xline');
U0 = zeros(dyn.Nt,dyn.Udim);
[~ ,YTarget] = solve(dyn,'Control',U0);
YTarget(:,1) = 0;
YTarget(:,end) = 0;


%%
[XXref,TTref] = ndgrid(xlineREF,tlineREF)
[XX,TT] = ndgrid(xline,tline)

%%
yinterp = y+YTarget';
yinterp(yinterp<0) = 0;
yinterp(1,:) = 0;
yinterp(end,:) = 0;

F = griddedInterpolant(XX,TT,yinterp,'spline');
FREF = F(XXref,TTref);
FREF(FREF<0) = 0;

%%
FT = griddedInterpolant(XX,TT,YTarget','spline');
FTREF = FT(XXref,TTref);

%% Ref Control
FTU = griddedInterpolant(XX,TT,w,'spline');
FUREF = FTU(XXref,TTref);
FUREF(FUREF<0) = 0;


%%

a = -0.3; b = 0.8;

A = -FEFractionalLaplacian(0.8,1,length(xlineREF));
B = BInterior(xlineREF,a,b);
dyn = pde('A',A,'B',B);
dyn.InitialCondition = 0.5*sin(0.5*pi*xline');
dyn.FinalTime = T;
dyn.Nt = length(tlineREF);
dyn.mesh = xlineREF;
dyn.Control.Numeric = W2';
dyn.StateVector.Numeric = FREF';
dyn.label = 'dynamics';
%%

%%
animation(dyn,'xx',0.01,'YLim',[0 10],'YLimControl',[0 100],'ControlShadow',true,'SaveGif',true,'Target',FTREF(:,end)')

%%


