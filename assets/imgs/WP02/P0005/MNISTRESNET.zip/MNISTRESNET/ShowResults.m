clear

load('matlab.mat')

%%
clf
nn = 3;

con = 0;
for i = 1:nn^2
   subplot(nn,nn,i)
   surf(XTrain(:,:,:,i))
   %shading interp
   axis('off')
   view(0,-90)
   Y = net.predict(XTrain(:,:,:,i));
   Y = reshape(Y,10,Nt);
   [~,ind] = max(Y(:,Nt));
   title("y = ("+num2str(Ymatrix(YTrain(i),:))+")")
   if  double(YTrain(i)) == (ind)
    con = con + 1;
   end

end

%% Mean of trajectories

[~,~,~,Ndata] = size(XTrain);

indexs = randsample(Ndata,200);
Y = net.predict(XTrain(:,:,:,indexs));
Y= reshape(Y,10,Nt,200);
%%
surf(Y(:,:,2))

%%

clf
nn = 6;

con = 0;
for i = 1:nn^2
   subplot(nn,nn,i)
   surf(XTrain(:,:,:,i))
   shading interp
   axis('off')
   view(0,-90)
   Y = net.predict(XTrain(:,:,:,i));
   Y = reshape(Y,10,Nt);
   title('Input')
   [~,ind] = max(Y(:,Nt));
   title("result "+(ind-1))
   
   if  double(YTrain(i)) == (ind)
    con = con + 1;
   end
   subplot(nn,nn,i+1)
   surf(1:Nt,1:10,Y)
    ylabel('Neurons')

    if true
   xlabel('Nt')
   [~,ind] = max(Y(:,Nt));
   title("result "+(ind-1))
   jj = 0;
   for it = 1:4:Nt
       jj = jj+1;
   subplot(nn,nn,i+jj+1)
   plot(Y(:,it))
   ylim([-1.5 1.5])
   title("Nt = "+it)
   xlabel('P*outputs')
   end
      subplot(nn,nn,i+jj+2)

   plot(sum(Y.^2))
   title('L2')
   xlabel('Nt')
   [~,ind] = max(Y);
   ind-1
   Y
   pause()
    end
end
%%
con/nn^2

