function [X,Y] = read_cifar( filename )

 cifar = load( filename );

end
