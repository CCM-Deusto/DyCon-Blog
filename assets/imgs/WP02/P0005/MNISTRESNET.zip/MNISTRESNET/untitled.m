import casadi.* 

x = casadi.SX.sym('x',10,1);

% Scalar
Cost = x'*x;
% Vectorial 
%Cost  = sin(x);


F = casadi.Function('F',{x},{Cost});


% si es scalar
dFdx = gradient(F(x),x);
% si F va de vector a vector
%dFdx = jacobian(F(x),x);

dFdx_dfcn = casadi.Function('dF',{x},{dFdx});

%%

import casadi.* 

x = SX.sym('x');
y = SX.sym('y'); 
z = SX.sym('z');
%
nlp = struct('x',[x;y;z], 'f',x^2+100*z^2, 'g',z+(1-x)^2-y);

S = nlpsol('S', 'ipopt', nlp);
disp(S)