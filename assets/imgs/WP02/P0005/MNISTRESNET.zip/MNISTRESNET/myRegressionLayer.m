classdef myRegressionLayer < nnet.layer.RegressionLayer
        
    properties
        % (Optional) Layer properties.
        P 
        nb_features
        Nt
        % Layer properties go here.
    end
 
    methods
        function layer = myRegressionLayer(Name,nb_features,Nt)
            layer.nb_features = nb_features;
            % (Optional) Create a myRegressionLayer.
            layer.Name = Name;
            % Layer constructor function goes here.
            layer.Nt = Nt;

        end

        function loss = forwardLoss(layer, Y, T)
            % Return the loss between the predictions Y and the training
            % targets T.
            %
            % Inputs:
            %         layer - Output layer
            %         Y     – Predictions made by network
            %         T     – Training targets
            %
            % Output:
            %         loss  - Loss between Y and T
                        % Calculate MAE.
                        
            
            
            loss = mean(sum((T-Y).^2))/layer.Nt;
        end

    end
end