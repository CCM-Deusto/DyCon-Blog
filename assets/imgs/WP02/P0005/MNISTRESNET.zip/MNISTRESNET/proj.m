classdef proj < nnet.layer.Layer

    properties
        % (Optional) Layer properties.
        P
        % Layer properties go here.
    end

    properties (Learnable)
        % (Optional) Layer learnable parameters.
         
        % Layer learnable parameters go here.
    end
    
    methods
        function layer = proj(P,name)
            % (Optional) Create a myLayer.
            % This function must have the same name as the class.
            layer.P = P;
            layer.Name = name;
            % Layer constructor function goes here.
        end
        
        function Z = predict(layer, X)
            % Forward input data through the layer at prediction time and
            % output the result.
            %
 %           size(X)

            Z = layer.P'*squeeze(X);

             [~,m] = size(Z);
             Z = reshape(Z,1,1,10,m);
%                         size(Z)

        end



    end
end