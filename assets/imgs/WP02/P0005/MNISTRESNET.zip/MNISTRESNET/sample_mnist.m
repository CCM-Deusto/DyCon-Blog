clear 
reqToolboxes = {'Deep Learning Toolbox'};
if( ~checkToolboxes(reqToolboxes) )
 msg = 'It requires:';
 for i=1:numel(reqToolboxes)
  msg = [msg, reqToolboxes{i}, ', ' ];
 end
 msg = [msg, 'Please install these toolboxes.'];
 error(msg);
end


% help
% https://mathworks.com/help/deeplearning/ref/classify.html

addpath('datasets');

if( ~exist( 'train1000', 'var' ) )
    train1000 = false;
end

if( train1000 )
 [XTrain, YTrain, XTest, YTest] = load_train1000('mnist');
else
 [XTrain, YTrain, XTest, YTest] = load_dataset('mnist');
end


% nb_features = 256;
layers = [ imageInputLayer([28 28 1],'Name','in')         ];


nb_features = 32;
P = rand(nb_features,10);
%P = eye(10)
Nt = 20;
dt = 1/Nt;
for it = 1:Nt
    layers = [layers 
    fullyConnectedLayer(nb_features,'Name',"fc"+it)
    reluLayer('Name',"relu"+it)
    scalingLayer('Name',"dt"+it,'Scale',dt)
    additionLayer(2,'Name',"add"+it)]; 
end

iLG = layerGraph(layers);
iLG = addLayers(iLG,depthConcatenationLayer(Nt,'Name','concat'));
iLG = addLayers(iLG,myRegressionLayer('out',10,Nt));

iLG = connectLayers(iLG, "concat/out", "out");

for it = 1:Nt
    iLG = connectLayers(iLG,"fc"+it,"add"+it+"/in2");
    iLG = addLayers(iLG,proj(P,"proyector"+it));
    iLG = connectLayers(iLG, "add"+it, "proyector"+it);
    iLG = connectLayers(iLG, "proyector"+it, "concat/in"+it);
end
 
plot(iLG)
          

%%
Ymatrix = eye(10);
% 
% YYTest = [Ymatrix(YTest,:) zeros(length(YTest),Nt*nb_features-10)];
% YYTrain = [Ymatrix(YTrain,:) zeros(length(YTrain),Nt*nb_features-10)];
%%
YYTest = repmat(Ymatrix(YTest,:),1,Nt);
YYTrain = repmat(Ymatrix(YTrain,:),1,Nt);

options = trainingOptions('adam', ...
    'Shuffle','every-epoch', ...
    'MaxEpochs', 100, ...
    'MiniBatchSize', 500, ...
    'ValidationData',{XTest, YYTest}, ...
    'ValidationFrequency', 10, ...
    'Plots','training-progress');
%    'Plots','none');

options.L2Regularization = 1e-5;
net = trainNetwork(XTrain,YYTrain,iLG,options);

%%
clf
nn = 6;

con = 0;
for i = 1:nn^2
   subplot(nn,nn,i)
   surf(XTrain(:,:,:,i))
   shading interp
   axis('off')
   view(0,-90)
   Y = net.predict(XTrain(:,:,:,i));
   Y = reshape(Y,10,Nt);
   title('Input')
   [~,ind] = max(Y(:,Nt));
   title("result "+(ind-1))
   
   if  double(YTrain(i)) == (ind)
    con = con + 1;
   end
   subplot(nn,nn,i+1)
   surf(1:Nt,1:10,Y)
    ylabel('Neurons')

    if true
   xlabel('Nt')
   [~,ind] = max(Y(:,Nt));
   title("result "+(ind-1))
   jj = 0;
   for it = 1:4:Nt
       jj = jj+1;
   subplot(nn,nn,i+jj+1)
   plot(Y(:,it))
   ylim([-1.5 1.5])
   title("Nt = "+it)
   xlabel('P*outputs')
   end
      subplot(nn,nn,i+jj+2)

   plot(sum(Y.^2))
   title('L2')
   xlabel('Nt')
   [~,ind] = max(Y);
   ind-1
   Y
   pause()
    end
end
%%
con/nn^2

